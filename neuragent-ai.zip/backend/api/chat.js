// Sample backend API route
export default function handler(req, res) { res.json({ reply: 'Hello from Neuragent' }); }