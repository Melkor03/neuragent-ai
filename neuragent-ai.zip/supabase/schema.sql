-- Supabase schema
CREATE TABLE faqs (id serial PRIMARY KEY, question text, answer text);