// Landing page
export default function Home() { return <h1>Welcome to Neuragent</h1>; }