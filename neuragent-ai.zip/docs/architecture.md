# System Architecture

- GPT-4.1
- Pinecone
- Supabase
- Vercel
